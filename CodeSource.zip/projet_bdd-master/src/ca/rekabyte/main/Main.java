package ca.rekabyte.main;

import java.sql.*;

public class Main {


    public static void main(String[] args) throws SQLException {
        Main app = new Main();
        //app.connect();

        SceneManager scene = new SceneManager();

    }

}





